<!-- Mirrored from medicare.bold-themes.com/dentist/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 20 Aug 2023 18:59:44 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->


<head>
    <meta charset="utf-8">
    <title>Country Praderas del Nogal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="Country Praderas del Nogal - Tafí Viejo - Los Nogales - Tucumán">
    <meta name="keywords" content="country, praderas del nogal, country praderas del nogal, barrio privado, barrio privado praderas del nogal, los nogales, country en los nogales, barrio privado los nogales, countrys en tucumán">
    <meta name="copyright" content="Country Praderas del Nogal" />
    <meta name="author" content="Sebastian Maturana">
    <meta name="robots" content="index,follow" />
    <meta http-equiv="cache-control" content="no-cache"/>


    <link rel="shortcut icon" href="<?php echo e(asset ('img/logo.png')); ?>" />

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- The styles -->
    <link rel='stylesheet' href='<?php echo e(asset('css/bootstrap.min.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(asset('css/font-awesome.min.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(asset('css/animate.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(asset('css/owl.carousel.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(asset('css/venobox.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(asset('css/styles.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(asset('css/icon-styles.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(asset('css/bootstrap-social.css')); ?>' type='text/css' />
</head>






<?php /**PATH E:\Mis Proyectos\praderasdelnogal\resources\views/layout/praderas/htmlheader.blade.php ENDPATH**/ ?>